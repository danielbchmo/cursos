<?php include("cabecera.php");?>

    <div class="p-5 bg-light">
        <div class="container">
            <h1 class="display-3">Bienvenidos</h1>
            <p class="lead">Este es un portafolio privado</p>
            <hr class="my-2">
            <p>Más información</p>
            
        </div>
    </div>

<?php include("pie.php"); ?>
